﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidad
{
    public class UserE
    {
        public int user_Insert { get; set; }
        public string NombreInsert { get; set; }
        public DateTime FechaInsert { get; set; }
    }
}
