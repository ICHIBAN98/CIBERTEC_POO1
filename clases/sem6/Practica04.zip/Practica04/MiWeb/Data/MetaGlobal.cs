﻿namespace MiWeb.Data
{
    public class MetaGlobal
    {
        public static string RutaApi = "";

        public static void LoadRutaApi(string ruta) 
        { 
            RutaApi = ruta;
        }
    }
}
