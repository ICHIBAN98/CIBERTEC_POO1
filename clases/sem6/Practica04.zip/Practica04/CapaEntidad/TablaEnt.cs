﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CapaEntidad
{
    public class TablaEnt
    {
        public string Codtabla {  get; set; }
        public int Valor { get; set; }
        public string Nombre { get; set; }
        public string valor1 { get; set; }
        public string valor2 { get; set; }
        public int Estado {  get; set; }
    }
}
